﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PZ_9
{
    internal class Dva
    {
        public void OdinDouble(double valueDouble)
        {
            Console.WriteLine(valueDouble);
        }
        public void OdinInt(int valueInt)
        {
            Console.WriteLine(valueInt);
        }
        public void OdinChar(char valueChar)
        {
            Console.WriteLine(valueChar);
        }
    }
}