﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PZ_7
{
    internal class Pencil : Product
    {
        public string Company { get; set; }
        public bool EraserOnTheTop { get; set; }
    }
}
