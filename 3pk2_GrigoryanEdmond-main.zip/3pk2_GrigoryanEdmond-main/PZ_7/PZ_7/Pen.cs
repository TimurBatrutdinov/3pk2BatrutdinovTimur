﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PZ_7
{
    internal class Pen : Product
    {
        public string Ink { get; set; }
        public string RodThickness { get; set; }
    }
}
